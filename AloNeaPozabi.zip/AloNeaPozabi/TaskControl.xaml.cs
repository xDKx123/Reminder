﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Reminder
{
    /// <summary>
    /// Interaction logic for TaskControl.xaml
    /// </summary>
    public partial class TaskControl : UserControl
    {
        public TaskControl()
        {
            InitializeComponent();
            this.DataContext = this;
        }

        public TaskControl(string jName, DateTime dueDate, bool isdone)
        {
            InitializeComponent();
            this.DataContext = this;
            JobName = jName;
            DueDate = dueDate;
            IsComplete = isdone;
        }

        public string JobName {
            get { return TextBlockJobName.Text; }
            set { TextBlockJobName.Text = value; }
        }

        public DateTime DueDate {
            get {
                string tmp = TextBlockDueDate.Text;
                return DateTime.Parse(tmp);
            }
            set { TextBlockDueDate.Text = value.ToString("dd.MM.yyyy"); }
        }

        public bool IsComplete {
            get { return (bool)CheckboxIsCompleted.IsChecked; }
            set { CheckboxIsCompleted.IsChecked = value; }
        }
    }
}