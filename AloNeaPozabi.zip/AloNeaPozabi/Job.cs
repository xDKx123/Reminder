﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace Reminder
{
    public class Job : INotifyPropertyChanged
    {
        private int id;
        private string name;
        private bool isDone;
        private DateTime deadline;

        public Job(int id, string taskName, DateTime deadline, bool isDone)
        {
            JobName = taskName;
            Deadline = deadline;
            IsDone = isDone;
        }

        public int Id
        {
            get => id;
            set
            {
                id = value;
                OnPropertyChanged("Id");
            }
        }

        public bool IsDone {
            get => isDone;
            set {
                isDone = value;
                OnPropertyChanged("IsDone");
            }
        }



        public DateTime Deadline {
            get => deadline;
            set {
                deadline = value;
                OnPropertyChanged("Deadline");
            }
        }

        public string JobName {
            get => name;
            set {
                name = value;
                OnPropertyChanged("JobName");
            }
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion INotifyPropertyChanged Members
    }
}