﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Reminder
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            getItems();

            //TaskList seznam1 = new TaskList();
            //seznam1.ListName = " Prvi";
            //for (int i = 0; i < 5; i++)
            //{
            //    seznam1.AddTask(new Task("ime" + i, DateTime.Now.AddDays(-i), i % 2 == 0 ? true : false));
            //}

            //BuildAddStackPanel(seznam1);

            //TaskList seznam2 = new TaskList();
            //seznam2.ListName = " Drugi";
            //for (int i = 5; i < 10; i++)
            //{
            //    seznam2.AddTask(new Task("ime" + i, DateTime.Now.AddDays(i), i % 2 == 0 ? true : false));
            //}

            //BuildAddStackPanel(seznam2);

            //TaskList seznam3 = new TaskList();
            //seznam3.ListName = " Tretji";
            //for (int i = 10; i < 13; i++)
            //{
            //    seznam3.AddTask(new Task("ime" + i, DateTime.Now.AddDays(i), i % 2 == 0 ? true : false));
            //}
            //BuildAddStackPanel(seznam3);
        }

        private async void getItems()
        {
            var items = await TaskListRepository.getTaskLists();

            //Console.WriteLine(items);
            foreach (TaskList taskList in items)
            {
                BuildAddStackPanel(taskList);
            }
        }

        private async void BuildAddStackPanel(TaskList checks)
        {
            checks.Tasks = await TaskListItemsRepository.getTaskListItems(checks.Id);

            StackPanel panel = new StackPanel
            {
                Orientation = Orientation.Vertical,
            };

            ScrollViewer viewer = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                Margin = new Thickness(5)
            };

            viewer.Content = panel;

            Button btn = new Button
            {
                Name = "ButtonAddTask",
                Content = "Add New Task",
                Margin = new Thickness(2)
            };
            btn.Click += new RoutedEventHandler(ButtonAddTask_Click);

            TextBlock txt = new TextBlock
            {
                Background = new SolidColorBrush(Color.FromRgb(0x2A, 0x9D, 0x8F)),
                Foreground = Brushes.Black,
                Text = checks.ListName
            };

            panel.Children.Add(txt);

            foreach (var item in checks.Tasks)
            {
                TaskControl tc = new TaskControl(item.JobName, item.Deadline, item.IsDone);
                tc.MouseDoubleClick += Tc_MouseDoubleClick;
                if (DateTime.Compare(item.Deadline, DateTime.Now) >= 0)// a je overdue task
                {
                    tc.Background = Brushes.Red;
                }
                tc.Margin = new Thickness(5);
                panel.Children.Add(tc);
            }

            panel.Children.Add(btn);

            StackPanelChildContainer.Children.Add(viewer);

            //ja, vemo da je to hilariously suboptimalna implementacija
            //nareto je blo last minute
            //ampak vsaj to ni vec nas problem :^)

            //hvala zlahtic da si ravno nas izbral
            //god fucking dammit
        }

        private void Tc_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            TaskControl tc = (TaskControl)sender;

            JobEditor jedit = new JobEditor(tc.IsComplete, tc.DueDate, tc.JobName);
            jedit.ShowDialog();

            tc.JobName = jedit.TaskName;
            tc.DueDate = jedit.Deadline;
            tc.IsComplete = jedit.IsCompleted;
        }

        private void ButtonAddTask_Click(object sender, RoutedEventArgs e)//sadly samo za frontend, na backend ne pusha podatkov
        {
            Button btn = (Button)sender;
            StackPanel panel = (StackPanel)btn.Parent;

            JobEditor jedit = new JobEditor();
            jedit.ShowDialog();
            var tc = new TaskControl(jedit.TaskName, jedit.Deadline, jedit.IsCompleted);
            if (jedit.TaskName == "")
            {
                MessageBox.Show("Please enter a task name");
            }
            else
            {
                tc.Margin = new Thickness(5);
                panel.Children.Insert(1, tc);
            }
        }

        private void ButtonAddList_Click(object sender, RoutedEventArgs e)
        {
            ListEditor ledit = new ListEditor();
            ledit.ShowDialog();
            if (ledit.ListName == "" || ledit.TaskName == "")
            {
                MessageBox.Show("Please enter data");
            }
            else
            {
                TaskList seznam = new TaskList();
                seznam.ListName = ledit.ListName;
                //seznam.AddTask(new Task(ledit.TaskName, ledit.Deadline, false));

                BuildAddStackPanel(seznam);
            }
        }
    }
}