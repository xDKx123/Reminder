﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net;
using Newtonsoft.Json;

namespace Reminder
{
    public class TaskListItemsRepository
    {
        public static async Task<List<Job>> getTaskListItems(int taskListId)
        {
            Dictionary<string, string> values = new Dictionary<string, string> {};
            values.Add("taskId", taskListId.ToString());

            FormUrlEncodedContent content = new FormUrlEncodedContent(values);

            var response = await Configuration.client.PostAsync(Configuration.serverIp + Configuration.getTasks, content);

            if (response.StatusCode == HttpStatusCode.OK)
            {
                string cont = await response.Content.ReadAsStringAsync();

                Dictionary<string, List<Job>> deserialized = JsonConvert.DeserializeObject<Dictionary<string, List<Job>>>(cont);


                //return 0;
                return deserialized["tasks"];
            }
            return null;
        }
    }
}
