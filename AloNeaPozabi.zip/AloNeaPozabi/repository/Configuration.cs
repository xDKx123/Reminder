﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;

namespace Reminder
{
    public class Configuration
    {
        public static readonly string serverIp = "http://127.0.0.1:6060";
        public static readonly HttpClient client = new HttpClient();

        //routes
        public static readonly string getTaskLists = "/getTaskLists";
        public static readonly string getTasks = "/getTasks";
    }
}
