﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reminder
{
    public class TaskList
    {
        private int id;
        private List<Job> tasks;
        private string listName;

        public TaskList()
        {
            Tasks = new List<Job>();
            ListName = "";
        }

        public int Id
        {
            get => id;
            set
            {
                id = value;
                OnPropertyChanged("Id");
            }
        }

        public List<Job> Tasks {
            get => tasks;
            
            set {
                tasks = value;
                OnPropertyChanged("TaskList");
            }
        }

        public string ListName {
            get => listName;
            
            set {
                listName = value;
                OnPropertyChanged("ListName");
            }
        }

        public void AddTask(Job job)
        {
            Tasks.Add(job);
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion INotifyPropertyChanged Members
    }
}